package paasta.com.enjoybusan;

import android.content.res.Resources;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

import paasta.com.enjoybusan.adapter.MainPagerAdapter;
import paasta.com.enjoybusan.databinding.ActivityMainBinding;
import paasta.com.enjoybusan.model.TabMenu;
import paasta.com.enjoybusan.model.User;
import paasta.com.enjoybusan.utils.Tools;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding mBinding;
    private ActionBar mActionBar;
    private MainPagerAdapter mMainPagerAdapter;

    private User mUser;
    private ArrayList<String> mTitleList;
    private ArrayList<String> mCategoryList;
    private ArrayList<String> mDrawerMenuList;

    private boolean mIsNavigationHide = false;
    private boolean mIsSearchBarHide = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        mUser = bundle.getParcelable("user");

        initComponent();
        initToolbar();
        initNavigationMenu();
        initNavigationBottom();

        // Initialize Tab Menu
        mActionBar.setTitle(mTitleList.get(TabMenu.HOME));
        mBinding.containerDrawerContent.pager.setCurrentItem(TabMenu.HOME);
    }

    private void initComponent() {
        Resources res = getResources();
        String [] tab_names = res.getStringArray(R.array.tab_names);
        mTitleList = new ArrayList<>(Arrays.asList(tab_names));
        String [] category_names = res.getStringArray(R.array.category_names);
        mCategoryList = new ArrayList<>(Arrays.asList(category_names));
        String [] drawer_menu_names = res.getStringArray(R.array.drawer_menu_names);
        mDrawerMenuList = new ArrayList<>(Arrays.asList(drawer_menu_names));
    }

    private void initToolbar() {
        setSupportActionBar(mBinding.containerToolbar.toolbar);
        mActionBar = getSupportActionBar();
        assert mActionBar != null;
        mActionBar.setDisplayHomeAsUpEnabled(true);
        mActionBar.setHomeButtonEnabled(true);
        Tools.setSystemBarColor(this);
    }

    private void initNavigationMenu() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mBinding.drawerLayout, mBinding.containerToolbar.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };

        mBinding.drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        mBinding.navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(final MenuItem item) {
                Toast.makeText(getApplicationContext(), item.getTitle() + " Selected", Toast.LENGTH_SHORT).show();
                mBinding.drawerLayout.closeDrawers();
                return true;
            }
        });
        View header = mBinding.navView.getHeaderView(0);
    }

    private void initNavigationBottom() {
        mMainPagerAdapter = new MainPagerAdapter(getSupportFragmentManager());
        mBinding.containerDrawerContent.pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                mActionBar.setTitle(mTitleList.get(position));
                mBinding.containerDrawerContent.navigation.getMenu().getItem(position).setChecked(true);
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        mBinding.containerDrawerContent.pager.setAdapter(mMainPagerAdapter);
        mBinding.containerDrawerContent.navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        mActionBar.setTitle(mTitleList.get(TabMenu.HOME));
                        mBinding.containerDrawerContent.pager.setCurrentItem(TabMenu.HOME);
                        return true;
                    case R.id.navigation_categories:
                        mActionBar.setTitle(mTitleList.get(TabMenu.CATEGORIES));
                        mBinding.containerDrawerContent.pager.setCurrentItem(TabMenu.CATEGORIES);
                        return true;
                    case R.id.navigation_chatbot:
                        mActionBar.setTitle(mTitleList.get(TabMenu.CHATBOT));
                        mBinding.containerDrawerContent.pager.setCurrentItem(TabMenu.CHATBOT);
                        return true;
                    case R.id.navigation_news:
                        mActionBar.setTitle(mTitleList.get(TabMenu.NEWS));
                        mBinding.containerDrawerContent.pager.setCurrentItem(TabMenu.NEWS);
                        return true;
                }
                return false;
            }
        });
    }

//    private void animateNavigation(final boolean hide) {
//        if (mIsNavigationHide && hide || !mIsNavigationHide && !hide) return;
//        mIsNavigationHide = hide;
//        int moveY = hide ? (2 * navigation.getHeight()) : 0;
//        navigation.animate().translationY(moveY).setStartDelay(100).setDuration(300).start();
//    }

    private void animateSearchBar(final boolean hide) {
//        if (mIsSearchBarHide && hide || !mIsSearchBarHide && !hide) return;
//        mIsSearchBarHide = hide;
//        int moveY = hide ? -(2 * mBinding.containerSearchBar.searchBar.getHeight()) : 0;
//        mBinding.containerSearchBar.searchBar.animate().translationY(moveY).setStartDelay(100).setDuration(300).start();
    }
}
