package paasta.com.enjoybusan.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import paasta.com.enjoybusan.fragment.TabCategoriesFragment;
import paasta.com.enjoybusan.fragment.TabHomeFragment;
import paasta.com.enjoybusan.fragment.TabChatbotFragment;
import paasta.com.enjoybusan.fragment.TabNewsFragment;
import paasta.com.enjoybusan.model.TabMenu;

public class MainPagerAdapter extends FragmentPagerAdapter {
    private TabMenu mTabMenu;

    public MainPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTabMenu.mTabNames.get(position);
    }

    @Override
    public int getCount() {
        return mTabMenu.mTabNames.size();
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fm;

        switch(position) {
            case TabMenu.HOME:
                fm = TabHomeFragment.newInstance(position);
                break;

            case TabMenu.CATEGORIES:
                fm = TabCategoriesFragment.newInstance(position);
                break;

            case TabMenu.CHATBOT:
                fm = TabChatbotFragment.newInstance(position);
                break;

            case TabMenu.NEWS:
                fm = TabNewsFragment.newInstance(position);
                break;

            default:
                fm = null;
        }

        return fm;
    }
}
