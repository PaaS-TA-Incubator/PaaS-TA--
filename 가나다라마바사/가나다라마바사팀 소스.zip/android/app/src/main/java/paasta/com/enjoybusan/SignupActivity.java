package paasta.com.enjoybusan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class SignupActivity extends AppCompatActivity {
    private Button register_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //register_btn = findViewById(R.id.register_btn);
    }
}
