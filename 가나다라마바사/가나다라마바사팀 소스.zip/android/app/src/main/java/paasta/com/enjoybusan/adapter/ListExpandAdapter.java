package paasta.com.enjoybusan.adapter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import paasta.com.enjoybusan.BenefitListActivity;
import paasta.com.enjoybusan.MainActivity;
import paasta.com.enjoybusan.R;
import paasta.com.enjoybusan.model.Category;

import static android.support.v4.app.ActivityCompat.requestPermissions;
import static android.support.v4.app.ActivityCompat.shouldShowRequestPermissionRationale;

public class ListExpandAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Category> mItems = new ArrayList<>();
    private static int image=0;

    private Context mContext;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, Category obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public ListExpandAdapter(Context context, List<Category> items) {
        this.mItems = items;
        mContext = context;
    }

    public ListExpandAdapter(Context context, List<Category> items, int img) {
        this.mItems = items;
        mContext = context;
        image = img;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category, parent, false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof OriginalViewHolder) {
            final OriginalViewHolder view = (OriginalViewHolder) holder;

            final Category category = mItems.get(position);
            view.title.setText(category.title);
            view.region.setText(category.region);
            view.initDialog(mContext, category);
            if(image!=0)
                view.imgView.setImageResource(image);
        }
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView region;
        private Dialog dialog;
        private ImageView imgView;

        public OriginalViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.title);
            region = v.findViewById(R.id.region);
            imgView = v.findViewById(R.id.image);
            ImageButton expand_btn = v.findViewById(R.id.expand_bt);
            expand_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDialog(v);
                }
            });



        }

        private void initDialog(Context c, final Category category) {
            dialog = new Dialog(c);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
            dialog.setContentView(R.layout.detail_dialog);
            dialog.setCancelable(true);

            TextView dialog_title = dialog.findViewById(R.id.dialog_title);
            TextView dialog_target = dialog.findViewById(R.id.dialog_target);
            final TextView dialog_contact = dialog.findViewById(R.id.dialog_contact);
            TextView dialog_ask = dialog.findViewById(R.id.dialog_ask);
            Button dialog_link = dialog.findViewById(R.id.dialog_link);

            dialog_title.setText(category.title);
            dialog_target.setText(category.target);
            dialog_contact.setText(category.contact);
            dialog_ask.setText(category.ask);

            dialog_contact.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s = dialog_contact.getText().toString();
                    String phone_num="";
                    for(int i=0;i< s.length(); ++i) {
                        if(Character.isDigit(s.charAt(i)))
                            phone_num += s.charAt(i);
                    }
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone_num));
                    mContext.startActivity(intent);
//                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone_num));
//                    if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
//                        if (shouldShowRequestPermissionRationale(mActivity,Manifest.permission.CALL_PHONE)) {
//                            AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
//                            dialog.setTitle("권한이 필요합니다.")
//                                    .setMessage("이 기능을 사용하기 위해서는 단말기의 \"전화걸기\" 권한이 필요합니다. 계속 하시겠습니까?")
//                                    .setPositiveButton("네", new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int which) {
//                                            /** * 새로운 인스턴스(onClickListener)를 생성했기 때문에 * 버전체크를 다시 해준다. */
//                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                                                // CALL_PHONE 권한을 Android OS에 요청한다.
//                                                 requestPermissions(mActivity,new String[]{ Manifest.permission.CALL_PHONE }, 1000);
//                                            }
//                                        }
//                                    }) .setNegativeButton("아니요", new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int which) {
//                                            Toast.makeText(mContext, "기능을 취소했습니다", Toast.LENGTH_SHORT).show();
//                                        }
//                                    }) .create() .show();
//                        } // 최초로 권한을 요청할 때
//                        else { // CALL_PHONE 권한을 Android OS에 요청한다.
//                             requestPermissions(mActivity,new String[]{Manifest.permission.CALL_PHONE}, 1000);
//                        }
//                    }
//                    else {
//                          mContext.startActivity(intent);
//                    }
                }
            });

            dialog_link.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    Uri url = Uri.parse(category.link);
                    intent.setData(url);
                    mContext.startActivity(intent);
                }
            });
        }

        private void showDialog(View v) {
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

            dialog.show();
            dialog.getWindow().setAttributes(lp);
        }
    }
}
