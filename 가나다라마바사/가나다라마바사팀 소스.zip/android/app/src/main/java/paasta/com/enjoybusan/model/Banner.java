package paasta.com.enjoybusan.model;

import android.graphics.drawable.Drawable;

public class Banner {

    public int image;
    public String name;
    public String brief;
    public Integer counter = null;

}
