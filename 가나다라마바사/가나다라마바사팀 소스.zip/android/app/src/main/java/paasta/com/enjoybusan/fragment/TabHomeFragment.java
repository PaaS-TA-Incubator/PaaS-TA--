package paasta.com.enjoybusan.fragment;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

import paasta.com.enjoybusan.R;
import paasta.com.enjoybusan.adapter.ListAnimationAdapter;
import paasta.com.enjoybusan.data.DataGenerator;
import paasta.com.enjoybusan.databinding.FragmentTabHomeBinding;
import paasta.com.enjoybusan.model.Category;
import paasta.com.enjoybusan.model.Welfare;
import paasta.com.enjoybusan.utils.ItemAnimation;

public class TabHomeFragment extends Fragment {
    private FragmentTabHomeBinding mBinding;
    private Context mContext;

    private ListAnimationAdapter mListAnimationAdapter;
    private int mAnimationType = ItemAnimation.BOTTOM_UP;
    private Typeface mTfLight;
    private Typeface mTfRegular;
    private double[] mPieChartValues = {30.6, 23.6, 20.4, 19.4, 6.0};

    private static final String ARG_POSITION = "position";
    private int mPosition;


    private List<Welfare> mItems = new ArrayList<>();

    public static TabHomeFragment newInstance(int position) {
        Bundle bundle = new Bundle();
        TabHomeFragment fragment = new TabHomeFragment();
        bundle.putInt(ARG_POSITION, position);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assert getArguments() != null;
        mPosition = getArguments().getInt(ARG_POSITION);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_tab_home, container, false);
        mContext = mBinding.getRoot().getContext();

        initWelfareRankingList();
        initPieChart();

        return mBinding.getRoot();
    }

    private void initWelfareRankingList() {
        mBinding.rankingRecyclerview.setLayoutManager(new LinearLayoutManager(mBinding.getRoot().getContext()));
        mBinding.rankingRecyclerview.setHasFixedSize(true);
        ViewCompat.setNestedScrollingEnabled(mBinding.rankingRecyclerview, false);

        mItems = DataGenerator.getWelfareData(mContext);
        mItems.addAll(DataGenerator.getWelfareData(mContext));
        mItems.addAll(DataGenerator.getWelfareData(mContext));
        mItems.addAll(DataGenerator.getWelfareData(mContext));
        mItems.addAll(DataGenerator.getWelfareData(mContext));

        //set data and list adapter
        mListAnimationAdapter = new ListAnimationAdapter(mContext, mItems, mAnimationType);
        mBinding.rankingRecyclerview.setAdapter(mListAnimationAdapter);
    }

    private void initPieChart() {
        mBinding.pieChart.setUsePercentValues(true);
        mBinding.pieChart.getDescription();
        mBinding.pieChart.setExtraOffsets(5, 10, 5, 5);
        mBinding.pieChart.setDragDecelerationFrictionCoef(0.95f);

        mTfRegular = Typeface.createFromAsset(mContext.getAssets(), "fonts/OpenSans-Regular.ttf");
        mTfLight = Typeface.createFromAsset(mContext.getAssets(), "fonts/OpenSans-Light.ttf");
        mBinding.pieChart.setCenterTextTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/OpenSans-Light.ttf"));
        mBinding.pieChart.setCenterText(generateCenterSpannableText());

        mBinding.pieChart.setExtraOffsets(20.f, 0.f, 20.f, 0.f);
        mBinding.pieChart.setDrawHoleEnabled(true);
        mBinding.pieChart.setHoleColor(Color.WHITE);
        mBinding.pieChart.setTransparentCircleColor(Color.WHITE);
        mBinding.pieChart.setTransparentCircleAlpha(110);
        mBinding.pieChart.setHoleRadius(58f);
        mBinding.pieChart.setTransparentCircleRadius(61f);
        mBinding.pieChart.setDrawCenterText(true);
        mBinding.pieChart.setRotationAngle(0);

        // enable rotation of the chart by touch
        mBinding.pieChart.setRotationEnabled(true);
        mBinding.pieChart.setHighlightPerTapEnabled(true);

        // mChart.setUnit(" €");
        // mChart.setDrawUnitsInChart(true);

        // add a selection listener
        mBinding.pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                if (e == null)
                    return;
                Log.i("VAL SELECTED",
                        "Value: " + e.getY() + ", xIndex: " + e.getX()
                                + ", DataSet index: " + h.getDataSetIndex());
            }

            @Override
            public void onNothingSelected() {
                Log.i("PieChart", "nothing selected");
            }
        });

        setData(5, 100);

        mBinding.pieChart.animateY(1400, Easing.EasingOption.EaseInOutQuad);
        // mChart.spin(2000, 0, 360);

        Legend l = mBinding.pieChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f);
        l.setEnabled(false);

        // entry label styling
        mBinding.pieChart.setEntryLabelColor(Color.BLACK);
        mBinding.pieChart.setEntryLabelTypeface(mTfRegular);
        mBinding.pieChart.setEntryLabelTextSize(12f);
    }

    private SpannableString generateCenterSpannableText() {
        SpannableString s = new SpannableString("청년들이 많이 찾는\nKeyWords");
        s.setSpan(new RelativeSizeSpan(1.5f), 0, s.length()-8, 0);
        s.setSpan(new StyleSpan(Typeface.ITALIC), 0, s.length()-8, 0);

        s.setSpan(new RelativeSizeSpan(1.5f), s.length()-8, s.length(), 0);
        s.setSpan(new StyleSpan(Typeface.ITALIC), s.length()-8, s.length(), 0);
        return s;
    }


    private void setData(int count, float range) {

        float mult = range;

        ArrayList<PieEntry> entries = new ArrayList<PieEntry>();

        // NOTE: The order of the entries when being added to the entries array determines their position around the center of
        // the chart.

        int idx=0;
        for(Welfare wf : mListAnimationAdapter.getItems()) {
            entries.add(new PieEntry((float) mPieChartValues[idx++], wf.title));
            if(idx>4)
                break;

        }



        PieDataSet dataSet = new PieDataSet(entries, "Election Results");
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);

        // add a lot of colors

        ArrayList<Integer> colors = new ArrayList<Integer>();

        for (int c : ColorTemplate.VORDIPLOM_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.COLORFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.LIBERTY_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.PASTEL_COLORS)
            colors.add(c);

        colors.add(ColorTemplate.getHoloBlue());

        dataSet.setColors(colors);
        //dataSet.setSelectionShift(0f);


        dataSet.setValueLinePart1OffsetPercentage(80.f);
        dataSet.setValueLinePart1Length(0.2f);
        dataSet.setValueLinePart2Length(0.4f);
        //dataSet.setUsingSliceColorAsValueLineColor(true);

        //dataSet.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.BLACK);
        data.setValueTypeface(mTfRegular);
        mBinding.pieChart.setData(data);

        // undo all highlights
        mBinding.pieChart.highlightValues(null);

        mBinding.pieChart.invalidate();
    }
}
