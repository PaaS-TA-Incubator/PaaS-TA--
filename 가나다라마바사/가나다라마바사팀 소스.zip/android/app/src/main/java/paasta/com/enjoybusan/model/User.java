package paasta.com.enjoybusan.model;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class User implements Parcelable {
    public String email;
    public String passwd;
    public String name;
    public String birth;
    public String edu;
    public String gender;
    public int marriage;
    public int job;
    public int income;
    public Bitmap icon;

    public User(String pEmail, String pPasswd, String pName, String pBirth, String pEdu, String pGender, int pMarriage, int pJob, int pIncome) {
        email = pEmail;
        passwd = pPasswd;
        name = pName;
        birth = pBirth;
        edu = pEdu;
        gender = pGender;
        marriage = pMarriage;
        job = pJob;
        income = pIncome;
    }

    private User(Parcel in) {
        readFromParcel(in);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(email);
        dest.writeString(passwd);
        dest.writeString(name);
        dest.writeString(birth);
        dest.writeString(edu);
        dest.writeString(gender);
        dest.writeInt(marriage);
        dest.writeInt(job);
        dest.writeInt(income);
    }

    private void readFromParcel(@NotNull Parcel in){
        email = in.readString();
        passwd = in.readString();
        name = in.readString();
        birth = in.readString();
        edu = in.readString();
        gender = in.readString();
        marriage = in.readInt();
        job = in.readInt();
        income = in.readInt();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        @NonNull
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @NonNull
        @Contract(pure = true)
        public User[] newArray(int size) {
            return new User[size];
        }
    };
}
