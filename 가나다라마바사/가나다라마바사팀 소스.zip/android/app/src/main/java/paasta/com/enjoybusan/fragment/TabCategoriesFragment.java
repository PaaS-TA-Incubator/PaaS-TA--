package paasta.com.enjoybusan.fragment;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import paasta.com.enjoybusan.BenefitListActivity;
import paasta.com.enjoybusan.R;
import paasta.com.enjoybusan.databinding.FragmentTabCategoriesBinding;

public class TabCategoriesFragment extends Fragment {
    private static final String ARG_POSITION = "position";

    private FragmentTabCategoriesBinding mBinding;
    private Context mContext;

    private int mPosition;

    public static TabCategoriesFragment newInstance(int position) {
        Bundle bundle = new Bundle();
        TabCategoriesFragment fragment = new TabCategoriesFragment();
        bundle.putInt(ARG_POSITION, position);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assert getArguments() != null;
        mPosition = getArguments().getInt(ARG_POSITION);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_tab_categories, container, false);
        mBinding.setFragment(this);
        mContext = mBinding.getRoot().getContext();

        return mBinding.getRoot();
    }

    public void callCategory(View view) {
        Intent intent = new Intent(getActivity(), BenefitListActivity.class);

        switch(view.getId()) {
            case R.id.health_category:
                intent.putExtra("caller", "health");
                intent.putExtra("img", R.drawable.category_health);
                break;

            case R.id.bokjiro_category:
                intent.putExtra("caller", "bokjiro");
                intent.putExtra("img", R.drawable.ic_welfare50);
                break;

            case R.id.gukbi_category:
                intent.putExtra("caller", "gukbi");
                intent.putExtra("img", R.drawable.category_education);
                break;

            case R.id.cityhall_category:
                intent.putExtra("caller", "cityhall");
                intent.putExtra("img", R.drawable.category_public);
                break;

            case R.id.busan_youth_category:
                intent.putExtra("caller", "busan_youth");
                intent.putExtra("img", R.drawable.category_community);
                break;

            case R.id.education_category:
                intent.putExtra("caller", "edu");
                intent.putExtra("img", R.drawable.category_edu);
                break;

            case R.id.job_category:
                intent.putExtra("caller", "hire");
                intent.putExtra("img", R.drawable.category_employ);
                break;

            case R.id.culture_category:
                intent.putExtra("caller", "culture");
                intent.putExtra("img", R.drawable.category_community);
                break;

            case R.id.finance_category:
                intent.putExtra("caller", "cash");
                intent.putExtra("img", R.drawable.category_finance);
                break;

            case R.id.house_category:
                intent.putExtra("caller", "house");
                intent.putExtra("img", R.drawable.category_housing);
                break;

            case R.id.secure_category:
                intent.putExtra("caller", "secure");
                intent.putExtra("img", R.drawable.category_law);
                break;

            case R.id.life_category:
                intent.putExtra("caller", "life");
                intent.putExtra("img", R.drawable.category_family);
                break;
            default:
        }

        mContext.startActivity(intent);
    }
}
