package paasta.com.enjoybusan.fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.text.InputType;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import com.github.bassaer.chatmessageview.model.ChatUser;
import com.github.bassaer.chatmessageview.model.IChatUser;
import com.github.bassaer.chatmessageview.model.Message;
import com.github.bassaer.chatmessageview.util.ChatBot;
import com.github.bassaer.chatmessageview.util.IMessageStatusIconFormatter;
import com.github.bassaer.chatmessageview.util.IMessageStatusTextFormatter;
import com.github.bassaer.chatmessageview.view.MessageView;

import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import paasta.com.enjoybusan.R;
import paasta.com.enjoybusan.databinding.FragmentTabChatbotBinding;
import paasta.com.enjoybusan.utils.AppData;
import paasta.com.enjoybusan.utils.MessageList;
import paasta.com.enjoybusan.utils.MyMessageStatusFormatter;

import static android.app.Activity.RESULT_OK;

public class TabChatbotFragment extends Fragment {
    private static final String SERVER_ADDRESS = "http://pub_rest.paas-ta.co.kr/post" ;

    @VisibleForTesting
    protected static final int RIGHT_BUBBLE_COLOR = R.color.colorPrimaryDark;
    @VisibleForTesting
    protected static final int LEFT_BUBBLE_COLOR = R.color.gray300;
    @VisibleForTesting
    protected static final int BACKGROUND_COLOR = R.color.mdtp_white;
    @VisibleForTesting
    protected static final int SEND_BUTTON_COLOR = R.color.blueGray500;
    @VisibleForTesting
    protected static final int SEND_ICON = R.drawable.ic_action_send;
    @VisibleForTesting
    protected static final int OPTION_BUTTON_COLOR = R.color.teal500;
    @VisibleForTesting
    protected static final int RIGHT_MESSAGE_TEXT_COLOR = Color.WHITE;
    @VisibleForTesting
    protected static final int LEFT_MESSAGE_TEXT_COLOR = Color.BLACK;
    @VisibleForTesting
    protected static final int USERNAME_TEXT_COLOR = Color.WHITE;
    @VisibleForTesting
    protected static final int SEND_TIME_TEXT_COLOR = Color.WHITE;
    @VisibleForTesting
    protected static final int DATA_SEPARATOR_COLOR = Color.WHITE;
    @VisibleForTesting
    protected static final int MESSAGE_STATUS_TEXT_COLOR = Color.WHITE;
    @VisibleForTesting
    protected static final String INPUT_TEXT_HINT = "New message..";
    @VisibleForTesting
    protected static final int MESSAGE_MARGIN = 5;

    private MessageList mMessageList;
    private ArrayList<ChatUser> mUsers;
    private static final int READ_REQUEST_CODE = 100;

    private FragmentTabChatbotBinding mBinding;
    private Context mContext;

    private static final String ARG_POSITION = "position";

    private int mPosition;

    public static TabChatbotFragment newInstance(int position) {
        Bundle bundle = new Bundle();
        TabChatbotFragment fragment = new TabChatbotFragment();
        bundle.putInt(ARG_POSITION, position);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assert getArguments() != null;
        mPosition = getArguments().getInt(ARG_POSITION);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_tab_chatbot, container, false);
        mContext = mBinding.getRoot().getContext();

        initUsers();
        initChatView();

        //Load saved messages
        loadMessages();

        return mBinding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        initUsers();
    }

    @Override
    public void onPause() {
        super.onPause();
        //Save message
        mMessageList = new MessageList();
        mMessageList.setMessages(mBinding.chatView.getMessageView().getMessageList());
        AppData.putMessageList(mContext, mMessageList);
    }

    private void initChatView() {
        //Set UI parameters if you need
        mBinding.chatView.setRightBubbleColor(ContextCompat.getColor(mContext,RIGHT_BUBBLE_COLOR));
        mBinding.chatView.setLeftBubbleColor(ContextCompat.getColor(mContext, LEFT_BUBBLE_COLOR));
        mBinding.chatView.setBackgroundColor(ContextCompat.getColor(mContext, BACKGROUND_COLOR));
        mBinding.chatView.setSendButtonColor(ContextCompat.getColor(mContext, SEND_BUTTON_COLOR));
        mBinding.chatView.setSendIcon(SEND_ICON);
        mBinding.chatView.setOptionIcon(R.drawable.ic_account_circle);
        mBinding.chatView.setOptionButtonColor(OPTION_BUTTON_COLOR);
        mBinding.chatView.setRightMessageTextColor(RIGHT_MESSAGE_TEXT_COLOR);
        mBinding.chatView.setLeftMessageTextColor(LEFT_MESSAGE_TEXT_COLOR);
        mBinding.chatView.setUsernameTextColor(USERNAME_TEXT_COLOR);
        mBinding.chatView.setSendTimeTextColor(SEND_TIME_TEXT_COLOR);
        mBinding.chatView.setDateSeparatorColor(DATA_SEPARATOR_COLOR);
        mBinding.chatView.setMessageStatusTextColor(MESSAGE_STATUS_TEXT_COLOR);
        mBinding.chatView.setInputTextHint(INPUT_TEXT_HINT);
        mBinding.chatView.setMessageMarginTop(MESSAGE_MARGIN);
        mBinding.chatView.setMessageMarginBottom(MESSAGE_MARGIN);
        mBinding.chatView.setMaxInputLine(5);
        mBinding.chatView.setUsernameFontSize(getResources().getDimension(R.dimen.font_small));
        mBinding.chatView.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        mBinding.chatView.setInputTextColor(ContextCompat.getColor(mContext, R.color.red500));
        mBinding.chatView.setInputTextSize(TypedValue.COMPLEX_UNIT_SP, 20);

        //Click Send Button
        mBinding.chatView.setOnClickSendButtonListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initUsers();
                //new message
                Message message = new Message.Builder()
                        .setUser(mUsers.get(0))
                        .setRight(true)
                        .setText(mBinding.chatView.getInputText())
                        .hideIcon(true)
                        .setStatusIconFormatter(new MyMessageStatusFormatter(mContext))
                        .setStatusTextFormatter(new MyMessageStatusFormatter(mContext))
                        .setStatusStyle(Message.Companion.getSTATUS_ICON())
                        .setStatus(MyMessageStatusFormatter.STATUS_DELIVERED)
                        .build();

                //Set to chat view
                mBinding.chatView.send(message);
                //Add message list
                mMessageList.add(message);

                new SendTask().execute(SERVER_ADDRESS, mBinding.chatView.getInputText());

                //Reset edit text
                mBinding.chatView.setInputText("");
            }

        });

        //Click option button
        mBinding.chatView.setOnClickOptionButtonListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != READ_REQUEST_CODE || resultCode != RESULT_OK || data == null) {
            return;
        }
        Uri uri = data.getData();
        try {
            Bitmap picture = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
            Message message = new Message.Builder()
                    .setRight(true)
                    .setText(Message.Type.PICTURE.name())
                    .setUser(mUsers.get(0))
                    .hideIcon(true)
                    .setPicture(picture)
                    .setType(Message.Type.PICTURE)
                    .setStatusIconFormatter(new MyMessageStatusFormatter(mContext))
                    .setStatusStyle(Message.Companion.getSTATUS_ICON())
                    .setStatus(MyMessageStatusFormatter.STATUS_DELIVERED)
                    .build();
            mBinding.chatView.send(message);
            //Add message list
            mMessageList.add(message);
            receiveMessage(Message.Type.PICTURE.name());
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(mContext, getString(R.string.error), Toast.LENGTH_SHORT).show();
        }
    }

    private void initUsers() {
        mUsers = new ArrayList<>();
        //User id
        int myId = 0;
        //User icon
        Bitmap myIcon = BitmapFactory.decodeResource(getResources(), R.drawable.face_2);
        //User name
        String myName = "문성욱";

        int chatbotID = 1;
        Bitmap chatbotIcon = BitmapFactory.decodeResource(getResources(), R.drawable.chatbot);
        String chatbotName = "부산봇";

        final ChatUser me = new ChatUser(myId, myName, myIcon);
        final ChatUser chatbot = new ChatUser(chatbotID, chatbotName, chatbotIcon);

        mUsers.add(me);
        mUsers.add(chatbot);
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");

        startActivityForResult(intent, READ_REQUEST_CODE);
    }

    private void showDialog() {
        final String[] items = { getString(R.string.send_picture), getString(R.string.clear_messages) };

        new AlertDialog.Builder(mContext).setTitle(getString(R.string.options)).setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int position) {
                switch (position) {
                    case 0 :
                        openGallery();
                        break;

                    case 1:
                        mBinding.chatView.getMessageView().removeAll();
                        break;
                }
            }
        })
        .show();
    }

    /**
     * Load saved messages
     */
    private void loadMessages() {
        List<Message> messages = new ArrayList<>();
        mMessageList = AppData.getMessageList(mContext);
        if (mMessageList == null) {
            mMessageList = new MessageList();
        } else {
            for (int i = 0; i < mMessageList.size(); i++) {
                Message message = mMessageList.get(i);
                //Set extra info because they were removed before save messages.
                for (IChatUser user : mUsers) {
                    if (message.getUser().getId().equals(user.getId())) {
                        message.getUser().setIcon(user.getIcon());
                    }
                }
                if (!message.isDateCell() && message.isRight()) {
                    message.hideIcon(true);

                }
                message.setStatusStyle(Message.Companion.getSTATUS_ICON_RIGHT_ONLY());
                message.setStatusIconFormatter(new MyMessageStatusFormatter(mContext));
                message.setStatus(MyMessageStatusFormatter.STATUS_DELIVERED);
                messages.add(message);
            }
        }
        MessageView messageView = mBinding.chatView.getMessageView();
        messageView.init(messages);
        messageView.setSelection(messageView.getCount() - 1);
    }

    private void receiveMessage(@NotNull String sendText) {
        //Receive message
        final Message receivedMessage = new Message.Builder()
                .setUser(mUsers.get(1))
                .setRight(false)
                .setText(sendText)
                .setStatusIconFormatter(new MyMessageStatusFormatter(mContext))
                .setStatusTextFormatter(new MyMessageStatusFormatter(mContext))
                .setStatusStyle(Message.Companion.getSTATUS_ICON())
                .setStatus(MyMessageStatusFormatter.STATUS_DELIVERED)
                .build();

        mBinding.chatView.receive(receivedMessage);
        //Add message list
        mMessageList.add(receivedMessage);
    }

    private class SendTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null ;
            BufferedReader reader = null ;
            String serverURL = params[0] ;
            String msg = params[1] ;

            try {
                URL url = new URL(serverURL) ; //Excute 함수의 param ( 서버주소 )
                connection = (HttpURLConnection) url.openConnection() ;

                connection.setRequestMethod("POST");    //POST방식으로 보냄
                connection.setRequestProperty("Cache-Control", "no-cache"); //캐시 설정
                connection.setRequestProperty("Content-Type", "application/json");  //application JSON 형식으로 전송
                connection.setRequestProperty("Accept", "text/html");   //서버에 response 데이터를 html로 받음
                connection.setDoOutput(true);   //Outstream으로 post 데이터를 넘겨주겠다는 의미
                connection.setDoInput(true);    //Inputstream으로 서버로부터 응답을 받겠다는 의미
                connection.connect();

                OutputStream outputStream = connection.getOutputStream() ;
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream)) ;
                writer.write(msg);
                writer.flush();
                writer.close();

                InputStream inputStream = connection.getInputStream() ;
                reader = new BufferedReader(new InputStreamReader(inputStream)) ;
                StringBuffer buffer = new StringBuffer() ;
                String line = "" ;
                while( (line = reader.readLine()) != null ) {
                    buffer.append(line) ;
                }
                return buffer.toString() ;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) connection.disconnect() ;

                try {
                    if (reader != null) reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            receiveMessage(result.toString());
        }
    }
}
