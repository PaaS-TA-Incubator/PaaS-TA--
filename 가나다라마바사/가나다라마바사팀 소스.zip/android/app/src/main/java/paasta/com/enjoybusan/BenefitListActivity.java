package paasta.com.enjoybusan;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import paasta.com.enjoybusan.adapter.ListExpandAdapter;
import paasta.com.enjoybusan.databinding.ActivityBenefitListBinding;
import paasta.com.enjoybusan.model.Category;
import paasta.com.enjoybusan.utils.ViewAnimation;
import paasta.com.enjoybusan.widget.LineItemDecoration;

public class BenefitListActivity extends AppCompatActivity {
    private ActivityBenefitListBinding mBinding;
    private ListExpandAdapter mAdapter;
    private ArrayList<Category> mList;
    private String[] location;
    private int loc_index=0;
    private int img;

    private final static int LOADING_DURATION = 3500;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_benefit_list);

        location = getResources().getStringArray(R.array.hierarchy_of_location);

        mBinding.searchX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBinding.searchField.setText(null);
                ((Button) findViewById(R.id.spn_state)).setText("    "+location[0]);
            }
        });

        mBinding.searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @SuppressLint("DefaultLocale")
            @Override
            public void afterTextChanged(Editable editable) {
                String searchText = editable.toString().trim();
                ArrayList<Category> searchedArray = new ArrayList<Category>();
                for (Category item : mList) {
                    if (item.title.contains(searchText)) {
                        searchedArray.add(item); // 검색
                    }
                }
                if (searchText.isEmpty()) {
                    mBinding.recyclerView.setAdapter(new ListExpandAdapter(BenefitListActivity.this, mList));
                    mBinding.searchX.setText(R.string.fontello_x_mark);
                } else {
                    mAdapter = new ListExpandAdapter(BenefitListActivity.this, searchedArray);
                    mBinding.recyclerView.setAdapter(mAdapter);
                    mBinding.searchX.setText(R.string.fontello_x_mark_masked);
                }
            }
        });

        Intent intent = getIntent();
        initData(intent.getStringExtra("caller"));
        img = intent.getIntExtra("img", -1);
    }

    private void initData(String caller) {
        if (caller.equals("health")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/cure");
        } else if (caller.equals("bokjiro")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/bokjiro_all");
        } else if (caller.equals("busan_youth")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/toyouth_all");
        } else if (caller.equals("gukbi")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/nationalcost_all");
        } else if (caller.equals("cityhall")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/cityhall_all");
        } else if (caller.equals("hire")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/hire");
        } else if (caller.equals("culture")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/culture");
        } else if (caller.equals("edu")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/edu");
        } else if (caller.equals("life")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/life");
        } else if (caller.equals("cash")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/cash");
        } else if (caller.equals("house")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/house");
        } else if (caller.equals("secure")) {
            new getData().execute("http://testdb2.paas-ta.co.kr/secure");
        }
    }

    private void initComponent() {
        mBinding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mBinding.recyclerView.addItemDecoration(new LineItemDecoration(this, LinearLayout.VERTICAL));
        mBinding.recyclerView.setHasFixedSize(true);

        //set data and list adapter
        mAdapter = new ListExpandAdapter(this, mList, img);
        mBinding.recyclerView.setAdapter(mAdapter);

        ((Button) findViewById(R.id.spn_state)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStateChoiceDialog((Button) v);
            }
        });
        // on item list clicked
//        mAdapter.setOnItemClickListener(new ListExpandAdapter.OnItemClickListener() {
//            @Override
//            public void onItemClick(View view, Social obj, int position) {
////                Snackbar.make(parent_view, "Item " + obj.name + " clicked", Snackbar.LENGTH_SHORT).show();
//            }
//        });
    }

    private void showStateChoiceDialog(final Button bt) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setSingleChoiceItems(location, loc_index, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                bt.setTextColor(getResources().getColor(R.color.main_color_grey_800));
                bt.setText("    "+location[which]);
                loc_index = which;
                ArrayList<Category> searchedArray = new ArrayList<Category>();
                for (Category item : mList) {
                    if (item.region.contains(location[which])) {
                        searchedArray.add(item);
                    }
                }
                if (which==0) {
                    mBinding.recyclerView.setAdapter(new ListExpandAdapter(BenefitListActivity.this, mList));
                    mBinding.searchX.setText(R.string.fontello_x_mark);
                } else {
                    mAdapter = new ListExpandAdapter(BenefitListActivity.this, searchedArray);
                    mBinding.recyclerView.setAdapter(mAdapter);
                }

            }

        });
        builder.show();
    }

//    private void loadingAndDisplayContent() {
//        final LinearLayout lyt_progress = (LinearLayout) findViewById(R.id.lyt_progress);
//        lyt_progress.setVisibility(View.VISIBLE);
//        lyt_progress.setAlpha(1.0f);
//        mBinding.recyclerView.setVisibility(View.GONE);
//
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                ViewAnimation.fadeOut(lyt_progress);
//            }
//        }, LOADING_DURATION);
//
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                initComponent();
//            }
//        }, LOADING_DURATION + 400);
//    }


    private class getData extends AsyncTask<String, Integer, ArrayList<Category>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Category> pCategories) {
            super.onPostExecute(pCategories);

            mList = pCategories;
            initComponent();
        }

        @Override
        protected ArrayList<Category> doInBackground(String... pURLS) {
            ArrayList<Category> arrayList = new ArrayList<>();
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(pURLS[0])
                    .get()
                    .build();

            try {
                Response response = client.newCall(request).execute();
                JSONArray jsonArray = new JSONArray(response.body().string());
                JSONObject jsonObject;

                for(int i = 0; i < jsonArray.length(); ++i) {
                    jsonObject = jsonArray.getJSONObject(i);
                    Category category = new Category();
                    category.title = String.valueOf(jsonObject.get("TITLE"));
                    category.region = String.valueOf(jsonObject.get("REGION"));
                    category.contents = String.valueOf(jsonObject.get("CONTENTS"));
                    category.target = String.valueOf(jsonObject.get("TARGET"));
                    category.date = String.valueOf(jsonObject.get("DATE"));
                    category.link = String.valueOf(jsonObject.get("LINK"));
                    category.ask = String.valueOf(jsonObject.get("ASK"));
                    category.contact = String.valueOf(jsonObject.get("CONTACT"));
                    category.origin = String.valueOf(jsonObject.get("ORIGIN"));
                    category.category = String.valueOf(jsonObject.get("CATEGORY"));
                    arrayList.add(category);
                }

            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }

            return arrayList;
        }
    }
}
