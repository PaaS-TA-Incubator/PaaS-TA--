package paasta.com.enjoybusan.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.balysv.materialripple.MaterialRippleLayout;

import java.util.List;

import paasta.com.enjoybusan.R;
import paasta.com.enjoybusan.model.Banner;
import paasta.com.enjoybusan.utils.Tools;

public class ImageSliderAdapter extends PagerAdapter {

    private Activity mActivity;
    private List<Banner> mItems;

    private ImageSliderAdapter.OnItemClickListener mOnItemClickListener;

    private interface OnItemClickListener {
        void mOnItemClickListener(View view, Banner obj);
    }

    public void setOnItemClickListener(ImageSliderAdapter.OnItemClickListener onItemClickListener) {
        mOnItemClickListener = onItemClickListener;
    }

    // constructor
    public ImageSliderAdapter(Activity activity, List<Banner> items) {
        mActivity = activity;
        mItems = items;
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    public Banner getItem(int pos) {
        return mItems.get(pos);
    }

    public void setItems(List<Banner> items) {
        mItems = items;
        notifyDataSetChanged();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((ConstraintLayout) object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        final Banner o = mItems.get(position);
        LayoutInflater inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.item_slider_image, container, false);

        ImageView image = (ImageView) v.findViewById(R.id.image);
        MaterialRippleLayout lyt_parent = (MaterialRippleLayout) v.findViewById(R.id.lyt_parent);
        Tools.displayImageOriginal(mActivity, image, o.image);
        lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                if (mOnItemClickListener != null) {
                    mOnItemClickListener.mOnItemClickListener(v, o);
                }
            }
        });

        ((ViewPager) container).addView(v);

        return v;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((ConstraintLayout) object);
    }
}
