package paasta.com.enjoybusan.model;

import android.graphics.drawable.Drawable;

public class Category {
    public String id;
    public String title;
    public String contents;
    public String date;
    public String target;
    public String link;
    public String region;
    public String ask;
    public String contact;
    public String origin;
    public String category;

    public Category() {
    }
}
