package paasta.com.enjoybusan;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import paasta.com.enjoybusan.databinding.ActivityLoginBinding;
import paasta.com.enjoybusan.model.User;

public class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding mBinding;
    private int callSignUp = 6740;
    private AlertDialog.Builder alert;
    private boolean failFlag = false;
    private String test;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_login);

        mBinding.email.setText("gukbab1216");
        mBinding.passwd.setText("1234");

        initAlert();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void callMainActivity(User pUser) {
        if(failFlag == false) {
         alert.show();
         return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("user", pUser);
        startActivity(intent);
    }

    private void initAlert() {
        alert = new AlertDialog.Builder(this);
        alert.setMessage("아이디 혹은 비밀번호가 잘못되었습니다.");
        alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
    }

    public void getUserInfo(View view) {
        String email = mBinding.email.getText().toString();
        String passwd = mBinding.passwd.getText().toString();

        new TryLogin().execute(new User(email, passwd, null, null, null, null, 0, 0, 0));
    }

    public void callSignUp(View view) {
        Intent intent = new Intent(this, SignupActivity.class);
        startActivityForResult(intent, callSignUp);
    }

    class TryLogin extends AsyncTask<User, Void, User> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(User pUser) {
            super.onPostExecute(pUser);
            callMainActivity(pUser);
        }

        @Override
        protected User doInBackground(User... pUsers) {
            String url = "http://user.paas-ta.co.kr/login?email=";
            url += pUsers[0].email;
            url += "&password=";
            url += pUsers[0].passwd;

            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder().url(url).get().build();

            try {
                Response response = client.newCall(request).execute();
                String responseMsg = response.body().string();
                JSONObject jsonObject = new JSONObject(responseMsg);
                String status = jsonObject.getString("status");
                if(status.compareTo("success")==0) {
                    failFlag = true;
                    JSONObject jsonUser = jsonObject.getJSONObject("user");
                    return new User(String.valueOf(jsonUser.get("email")), String.valueOf(jsonUser.get("password")),
                            String.valueOf(jsonUser.get("name")), String.valueOf(jsonUser.get("birth")), String.valueOf(jsonUser.get("education")),
                            String.valueOf(jsonUser.get("gender")), Integer.parseInt(String.valueOf(jsonUser.get("marriage"))),
                            Integer.parseInt(String.valueOf(jsonUser.get("job"))), Integer.parseInt(String.valueOf(jsonUser.get("income"))));
                }
                else {
                    failFlag = false;
                }
            } catch (JSONException | IOException pE) {
                pE.printStackTrace();

            }
            return new User("fail", null,null, null, null, null,0,0,0);
        }
    }
}
