package paasta.com.enjoybusan.model;

import java.util.ArrayList;

public interface TabMenu {
    public final int HOME = 0;
    public final int CATEGORIES = 1;
    public final int CHATBOT = 2;
    public final int NEWS = 3;

    public final ArrayList<String> mTabNames = new ArrayList<String>() {{
        add("Home");
        add("Categories");
        add("Chatbot");
        add("News");
    }};
}
