package paasta.com.enjoybusan.fragment;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import paasta.com.enjoybusan.R;
import paasta.com.enjoybusan.adapter.ImageSliderAdapter;
import paasta.com.enjoybusan.databinding.FragmentTabNewsBinding;
import paasta.com.enjoybusan.model.Banner;

public class TabNewsFragment extends Fragment {
    private FragmentTabNewsBinding mBinding;
    private Context mContext;
    private Runnable mRunnable = null;
    private Handler mHandler = new Handler();
    private ImageSliderAdapter mAdapterImageSlider;

    private static final String ARG_POSITION = "position";
    private int mPosition;

    public static int[] array_image_place = {
            R.drawable.one_poster,
            R.drawable.two_poster,
            R.drawable.three_poster,
            R.drawable.four_poster,
            R.drawable.five_poster
    };

    public static TabNewsFragment newInstance(int position) {
        Bundle bundle = new Bundle();
        TabNewsFragment fragment = new TabNewsFragment();
        bundle.putInt(ARG_POSITION, position);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assert getArguments() != null;
        mPosition = getArguments().getInt(ARG_POSITION);
    }

    @Override
    public void onDestroyView() {
        if (mRunnable != null) mHandler.removeCallbacks(mRunnable);
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_tab_news, container, false);
        mContext = mBinding.getRoot().getContext();
        initBanner();

        return mBinding.getRoot();
    }

    private void initBanner() {
        mAdapterImageSlider = new ImageSliderAdapter(getActivity(), new ArrayList<Banner>());

        final List<Banner> items = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Banner obj = new Banner();
            obj.image = array_image_place[i];
            items.add(obj);
        }

        mAdapterImageSlider.setItems(items);
        mBinding.pager.setAdapter(mAdapterImageSlider);

        // displaying selected image first
        mBinding.pager.setCurrentItem(0);
        addBottomDots(mBinding.layoutDots, mAdapterImageSlider.getCount(), 0);
        mBinding.pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int pos, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int pos) {
                addBottomDots(mBinding.layoutDots, mAdapterImageSlider.getCount(), pos);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        startAutoSlider(mAdapterImageSlider.getCount());
    }

    private void addBottomDots(@NotNull LinearLayout layout_dots, int size, int current) {
        ImageView[] dots = new ImageView[size];

        layout_dots.removeAllViews();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new ImageView(mContext);
            int width_height = 15;
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(new ViewGroup.LayoutParams(width_height, width_height));
            params.setMargins(10, 10, 10, 10);
            dots[i].setLayoutParams(params);
            dots[i].setImageResource(R.drawable.shape_circle_outline);
            layout_dots.addView(dots[i]);
        }

        if (dots.length > 0) {
            dots[current].setImageResource(R.drawable.shape_circle);
        }
    }

    private void startAutoSlider(final int count) {
        mRunnable = new Runnable() {
            @Override
            public void run() {
                int pos = mBinding.pager.getCurrentItem();
                pos = pos + 1;
                if (pos >= count) pos = 0;
                mBinding.pager.setCurrentItem(pos);
                mHandler.postDelayed(mRunnable, 7000);
            }
        };
        mHandler.postDelayed(mRunnable, 7000);
    }
}
