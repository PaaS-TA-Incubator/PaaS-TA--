# crawler-server(Flask server for crawling)

Paas-Ta's mysql server and flask server were used to create a crawl server.

